package Ex1;

public class Pessoa {
    Integer idade_anos;
    Integer idade_meses;
    Integer idade_dias;


    public Pessoa(Integer idade_anos, Integer idade_meses, Integer idade_dias) {
        this.idade_anos = idade_anos;
        this.idade_meses = idade_meses;
        this.idade_dias = idade_dias;

    }
}
