package Ex1;

public class Main {
    public static void main(String[] args) {
        Pessoa Guilherme = new Pessoa(3,2,15);
        Integer tempo_vida = Guilherme.idade_anos*365+ Guilherme.idade_meses*30+ Guilherme.idade_dias;
        System.out.printf("Tempo vivido em dias (no total): %d",tempo_vida);
    }

}
