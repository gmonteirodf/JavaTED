package Ex4;

public class IPI {
    Double ipi;

    public IPI(Double ipi) {
        this.ipi = ipi;
    }
}
