package Ex4;

public class Produto1 {
    Integer cod_produto;
    Double valor;
    Integer quantidade;

    public Produto1(Integer cod_produto, Double valor, Integer quantidade) {
        this.cod_produto = cod_produto;
        this.valor = valor;
        this.quantidade = quantidade;
    }
}
