package Ex5;

public class Pessoa  {
    Integer salario_min;
    Integer salario_usuario;

    public Pessoa(Integer salario_min, Integer salario_usuario) {
        this.salario_min = salario_min;
        this.salario_usuario = salario_usuario;
    }
}
