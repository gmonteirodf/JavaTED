package Ex6;

public class Num {
    Integer numero;

    public Num(Integer numero) {
        this.numero = numero;

    }
}
